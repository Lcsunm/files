## v2.0.1 ##

* Integrate with ads-sdk 3.0.

## v2.0.2 ##

* use international news when fetch content is empty.

## v2.0.3 ##

* Integration with new opera news openAPI

## v2.0.4 ##

* Updated Terms
* Add 12 new language translations to news app.
* When no internet connection give user a hint.

## v2.0.5 ##

* The page will freeze when disable WIFI.
* Correct language code for Norweigian News app (no-NO->nb-NO)

## v2.0.6 ##

* First categories option shouldn' t overlap the text above.
* Fix lang cs-cz to cs-CZ.

## v2.0.7 ##

* Update Czech and Italiano license terms

## v2.0.8 ##

* Adjust kaiNews architect for opera new API(workround).

## v2.0.9 ##

* Fix CI error.
* Remove country list from opera API instead of local country list json file.
* Verify opera 34 countries api work status.

## v2.1.0 ##

* Add extra country which opera new api did not support
* Fallback to global en contents when fetch failed.

## v2.1.1 ##

* Fix details page can not open which related country is opera opened for kai.

## v2.1.2 ##

* KaiNews new ads placement.

## v2.1.3 ##

* Enable click link in terms page.

## v2.1.4 ##

* Add simplified chinese, vietnamese, hindi, and Traditional Chinese support in KaiNews.

## v2.1.5 ##

* Add rtl layout to the terms page.

## v2.1.6 ##

* Add Hebrew support for customer's request in KaiNews.

## v2.1.7 ##

* Solve the problem that a blank screen appears when you click ArrowLeft.

## v2.1.8 ##

* Change http to https.
* DUT should can choose the first URL in terms of services.

## v2.1.9 ##

* Pre sync one category to reduce loading time.
* Enable timer tick just when ads is on.

## v2.2.0 ##

* zh-CN translation should be changed from '选择地区' to '选择'.

## v2.2.1 ##

* revert Bug-102408.

## v2.2.2 ##

* ads implementation for home.js & details.js.

## v2.2.3 ##

* new ads implementation.
* fix ad banner on detail screen not clicking.
* add banner ad loading indicator.
* cancelling the text above the READMORE button on Detail.js
* Remove code-coverage from CI config file avoid CI failed.
* Modify permission declaration to meet China Type Approval requirement.

## v2.2.4 ##

* Crash when device locale is region-less.
* Restoring banner ads slot id in ad config.
* Detail.js (Article Screen) Softkey Behavior Update: Once the user moved away from the ad banner from the screen, selection to the ads should be dismissed.
* Update latest Ads SDK dependency.
* KaiNews-zh-CN and vi-VN translation update.

## v2.2.5 ##

* Add zu-ZA locale for KaiNews.

## v2.2.6 ##

* Update latest Ads SDK dependency to v1.4.2.

## v2.2.7 ##

* Update latest Ads SDK dependency to v1.4.3.

## v2.2.8 ##

* KaiNews translation shortening for es-ES.
